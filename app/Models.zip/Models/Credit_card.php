<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Credit_card extends Model
{
    use HasFactory;
    protected $fillable = [
        // customer_id    card_no    exp_month    exp_year    cvc
        'customer_id',
        'card_no',
        'exp_month',
        'exp_year',
        'cvc',
    ];

    public function Customer()
    {
        return $this->belongsTo(Customer::class);
    }

}
