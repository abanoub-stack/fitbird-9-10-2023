<?php

namespace App\Http\Controllers;

use App\Models\Customer;

class UserController extends Controller
{
    public function index()
    {
        $users = Customer::orderBy('id', 'desc')->paginate(10);
        return view('user.index', [
            'users' => $users,
        ]);
    }

    public function user($uId)
    {
        $user = Customer::findOrFail($uId);
        return view('user.user', [
            'user' => $user,
        ]);
    }

}
