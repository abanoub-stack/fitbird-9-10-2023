<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use App\Http\Resources\AddressResource;
use App\Http\Resources\CreditCardResource;
use App\Http\Resources\CustomerResource;
use App\Models\Address;
use App\Models\Credit_card;
use App\Models\Customer;
use App\Models\CustomerNotification;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;


class AuthController extends Controller
{

    public function register(Request $request)
    {
        # Customer
        #// Validation
        $validator = Validator::make($request->all(), [
            'email' => 'required|email|max:50|unique:customers,email',
            'name' => 'required|string|min:4|max:50',
            'phone' => 'required|string',
            'gender' => 'required|string|max:6',
            'password' => 'required|string|min:4|max:64|confirmed',
            'age' => 'required|numeric|max:90',
            'height' => 'required|numeric|min:100|max:300',
            'exercise_days' => 'required|numeric|min:1|max:7',
            'workout_intensity' => 'required|string|max:255',

            'stripe_id' => 'nullable',
            'pm_type' => 'nullable',
            'pm_last_four' => 'nullable',
            'trail_ends_at' => 'nullable',
            'access_token' => 'nullable',
            //
            # Address
            // 'customer_id',
            'city' => 'required|string|max:50',
            'country' => 'required|string|min:2|max:2',
            'line1' => 'required|string|max:255',
            'line2' => 'nullable|string|max:255',
            'postal_code' => 'required|numeric|min:111|max:9999',
            'state' => 'required|string|max:64',
            //
            # Credit Card
            // 'customer_id',
            'card_no' => 'nullable|numeric|unique:credit_cards,card_no',
            'exp_month' => 'nullable|numeric|max:12',
            'exp_year' => 'nullable|numeric|max:2100',
            'cvc' => 'nullable|numeric|max:9999',
        ]);
        // Check Vakidation
        if ($validator->fails()) {
            return response()->json([
                'required' => $validator->errors(),
                'nullable' => ['address_information' => 'line2',
                    'credit_card_information' => [
                        'card_no',
                        'exp_month',
                        'exp_year',
                        'cvc',
                    ],
                ],
            ]);
        }

        // Do Success Tables Creation After Validation
        // Access Token
        $access_token = Str::random(128);

        // # Customer
        $customer = Customer::create([
            'email' => $request->email,
            'name' => $request->name,
            'phone' => $request->phone,
            'gender' => $request->gender,
            'workout_intensity' => $request->workout_intensity,
            'age' => $request->age,
            'height' => $request->height,
            'exercise_days' => $request->exercise_days,
            'password' => bcrypt($request->password),
            'access_token' => $access_token,
        ]);

        // Address
        $address = Address::create([
            'customer_id' => $customer->id,
            'city' => $request->city,
            'country' => $request->country,
            'line1' => $request->line1,
            'line2' => $request->line2 ?? null,
            'postal_code' => $request->postal_code,
            'state' => $request->state,
        ]);
        CustomerNotification::create([
            'user' => "$customer->email",
            'message' => __('added address in registration'),
        ]);
        // Credit Card
        if ($request->has('card_no')) {
            $creditCard = Credit_card::create([
                'customer_id' => $customer->id,
                'card_no' => $request->card_no,
                'exp_month' => $request->exp_month,
                'exp_year' => $request->exp_year,
                'cvc' => $request->cvc,
            ]);
            CustomerNotification::create([
                'user' => "$customer->email",
                'message' => __('added credit card in registeration'),
            ]);
        } else {
            $creditCard = Credit_card::create([
                'customer_id' => $customer->id,
            ]);
        }
        CustomerNotification::create([
            'user' => "$customer->email",
            'message' => __('registered'),
        ]);
        // Return success data
        return response()->json([
            'access_token' => $access_token,
            'customer' => new CustomerResource($customer),
            'address' => new AddressResource($address),
            'credit_card' => new CreditCardResource($creditCard),
            'next_request' => url('api/v1'),
        ]);

    }

    public function login(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name_or_phone_or_email' => 'required|string|max:255',
            'password' => 'required|string|min:4',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => $validator->errors(),
            ]);
        }
        $user = Customer::where('name', '=', $request->name_or_phone_or_email)
            ->orWhere('email', '=', $request->name_or_phone_or_email)
            ->orWhere('phone', '=', $request->name_or_phone_or_email)
            ->first();
        $access_token = Str::random(128);

        if (!$user) {
            return response()->json([
                'error' => __('user not found'),
            ]);
        }
        if ($user->access_token !== null && Hash::check($request->password, $user->password)) {
            return response()->json([
                'error' => __('user already logged in'),
                'access_token' => $user->access_token,
            ]);
        }
        $password = $request->password;
        $isCorrect = Hash::check($password, $user->password);
        if (!$isCorrect) {
            return response()->json([
                'error' => __('password not correct'),
            ]);
        }
        $user->update([
            'access_token' => $access_token,
        ]);
        CustomerNotification::create([
            'user' => "$user->email",
            'message' => __('logged in'),
        ]);
        return response()->json([
            'message' => __('user logged in successfully'),
            'access_token' => $access_token,
            'next_request' => url('api/v1'),
            'user' => new CustomerResource($user),
        ]);
    }

    public function logout(Request $request)
    {
        $user = Customer::where('access_token', '=', $request->header('access_token'))->first();
        $user->update([
            'access_token' => null,
        ]);
        CustomerNotification::create([
            'user' => $user->email,
            'message' => __('logged out'),
        ]);
        return response()->json([
            'message' => __('user logged out successfully'),
            'next_request' => url('api/v1/login'),
        ]);
    }

    public function schedule(Schedule $schedule, Request $request)
    {
        if ($request->header('access_token')) {
            $user = Customer::where('access_token', '=', $request->header('access_token'))->first();
            if ($user) {
                $schedule->command($user->update([
                    'access_token' => null,
                ]))->everyTwoMinutes();
            }
        }
    }

}
