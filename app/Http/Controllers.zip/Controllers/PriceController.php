<?php

namespace App\Http\Controllers;

use App\Models\Price;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PriceController extends Controller
{
    public function price()
    {
        if (Price::all()->count() == 0) {
            Price::create([
                'price' => 1,
            ]);
            Auth::logout();
            return view('auth.login');
        }

        $price = Price::all()->first();
        return view('price.price', [
            'price' => $price,
        ]);
    }

    public function pricePost(Request $request)
    {
        $price = Price::all()->first();

        $n = Price::all()->first();
        $isCorrect = Price::findOrFail($n->id);
        if ($isCorrect) {
            $request->validate([
                'price' => 'required|numeric|unique:prices,price',
            ]);
            $price = $isCorrect;
            $price->update([
                'price' => $request->price,
            ]);
            return back();
        }
    }

}
