<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Package;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PackageController extends Controller
{
    public function allPackages()
    {
        // ->unique('customer_id')
        $packages = Package::orderBy('name', 'desc')->get();
        return view('package.all-packages', [
            'packages' => $packages,
        ]);
    }

    public function showPackage($packageId)
    {
        $package = Package::findOrFail($packageId);
        $customer = $package->Customer;
        return view('package.show-package', [
            'package' => $package,
            'customer' => $customer,
        ]);
    }

    public function addPackage()
    {
        return view('package.add-package');
    }

    public function addPackagePost(Request $request)
    {
        $request->validate([
            'name' => 'required|string|unique:packages,name',
            'customer' => 'required|numeric|exists:customers,id',
            'category' => 'required|exists:categories,id',
        ]);

        foreach (DB::table('exercises')->get() as $ex) {
            if ($request->has("exercise_$ex->id")) {
                $exercises_id[] = $ex->id;
            }
        }
        foreach ($exercises_id as $exercise) {
            Package::create([
                'name' => $request->name,
                'customer_id' => $request->customer,
                'category_id' => $request->category,
                'exercise_id' => $exercise,
            ]);
        }
        return redirect(url('packages'));
    }

    public function deletePackage($packageId)
    {
        $package = Package::findOrFail($packageId);
        $package->delete();
        return redirect(url('/packages'));
    }

}
