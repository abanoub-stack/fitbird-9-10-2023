@extends('layouts.layout')
@section('title')
Users
@endsection
@section('css')
<!-- Custom styles for this page -->
@endsection


@section('content')

@section('head-title')
All Users
@endsection



<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">All Users</h6>
    </div>
    <div class="card-body">

        {{-- Table --}}
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Email</th>
                            <th scope="col">Name</th>
                            <th scope="col">Phone</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Workout Intensity</th>
                            <th scope="col">Age</th>
                            <th scope="col">Height</th>
                            <th scope="col">Exercise Days</th>
                            <th scope="col">Payment Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($users as $i => $user)
                            <tr>
                                <th scope="row">{{ $i + 1 }}</th>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->phone }}</td>
                                <td>{{ $user->gender }}</td>
                                <td>{{ $user->workout_intensity }}</td>
                                <td>{{ $user->age }}</td>
                                <td>{{ $user->height }}</td>
                                <td>{{ $user->exercise_days }}</td>
                                @if ($user->is_subscribed == '1')
                                    <td class="text-success"><strong>{{ 'User Subscribed' }}</strong></td>
                                @else
                                    <td class="text-danger"><strong>{{ 'User Not Subscribed' }}</strong></td>
                                @endif
                                <td>
                                    <a class="btn btn-sm btn-primary" href="{{ url('user', $user->id) }}">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <th colspan="11"><div class="d-flex justify-content-center">{{ $users->links() }}</div></th>
                        </tr>
                    </tfoot>

                </table>
            </div>
        {{-- Table --}}

    </div>
</div>



@endsection

<!-- Page level plugins -->
<script src="{{asset('dashboard/vendor/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('dashboard/vendor/datatables/dataTables.bootstrap4.min.js')}}"></script>

<!-- Page level custom scripts -->
<script src="{{asset('dashboard/js/demo/datatables-demo.js')}}"></script>


